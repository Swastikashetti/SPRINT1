package com.cg.ppmtoolapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PpmtoolapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
