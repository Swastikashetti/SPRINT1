package com.cg.ppmtoolapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PpmtoolapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PpmtoolapiApplication.class, args);
	}

}
